<?php
if (isset($_GET['mn'])) {
    $mn = intval($_GET['mn']);
} else {
    $mn = 0;
}
$id = ($_GET['id']);
$val = $_GET['val'];
$rn = $_GET['rn'];

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "university";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);


$inputArr = split("~", $val);

if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);
if($mn == 0){
     if ($inputArr[0] > 0 && strlen($inputArr[1]) > 0 && $inputArr[2] > 0 && strlen($inputArr[3]) > 0) {

 $query = "UPDATE student SET student_number = '$inputArr[0]', name = '$inputArr[1]',"
         . " myclass = '$inputArr[2]', major = '$inputArr[3]' WHERE student_number = $id";
 mysql_query($query);
     }
     else{ $val = "error";}
}


if($mn == 1){
if (strlen($inputArr[0]) > 0 && strlen($inputArr[1]) > 0 && $inputArr[2] > 0 && strlen($inputArr[3]) > 0) {
 $query = "UPDATE course SET course_number = '$inputArr[0]', course_name = '$inputArr[1]',"
         . " credit_hours = '$inputArr[2]', department = '$inputArr[3]' WHERE course_number = '$id'";
 mysql_query($query);
}
else{ $val = "error";}
}

if($mn == 2){
if ($inputArr[0] > 0 && strlen($inputArr[1]) > 0 && strlen($inputArr[2]) > 0 && strlen($inputArr[3]) > 0 && strlen($inputArr[4]) > 0) {
 $query = "UPDATE mysection SET section_identifier = '$inputArr[0]', course_number = '$inputArr[1]',"
         . " semester = '$inputArr[2]', myyear = '$inputArr[3]', instructor = '$inputArr[4]' WHERE section_identifier = '$id'";
 mysql_query($query);
}
else{ $val = "error";}
}

if($mn == 3){
if ($inputArr[0] > 0 && $inputArr[1] > 0 && strlen($inputArr[2])> 0) {

 $query = "UPDATE grade_report SET student_number = '$inputArr[0]', section_identifier = '$inputArr[1]',"
         . " grade = '$inputArr[2]' WHERE section_identifier = '$id'";
 mysql_query($query);
 
 //(student_number, section_identifier, grade)
}
else{ $val = "error";}
}

if($mn == 4){
$idArr = split("~", $id);    
 if (strlen($inputArr[0]) > 0 && strlen($inputArr[1]) > 0) {
 
 $query = "UPDATE prerequisite SET course_number = '$inputArr[0]', prerequisite_number = '$inputArr[1]'"
         . " WHERE (course_number = '$idArr[0]') AND (prerequisite_number = '$idArr[1]')";
 mysql_query($query);
 }
 else{ $val = "error";}
}

    
    $out = "$val";
   


mysql_close($con);

print $out;
?>